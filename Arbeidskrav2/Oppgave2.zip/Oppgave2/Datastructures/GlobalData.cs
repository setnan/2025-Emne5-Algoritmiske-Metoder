namespace Oppgave2;


public static class GlobalData
{
    List<int> numbers = new() { 50, 60, 61, 70, 75, 80, 85, 100, 110, 115, 118, 120, 128, 130, 140 };

}

