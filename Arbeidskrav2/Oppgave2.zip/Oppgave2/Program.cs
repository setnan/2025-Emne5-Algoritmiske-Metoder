﻿using Oppgave2;

    int FoundIndex = -1;

if (numbers.Count % 2 == 0) FoundIndex = numbers.Count / 2;

else FoundIndex = (numbers.Count - 1) / 2;



// Console.WriteLine($"Antall noder i treet: {numbers.Count}");

// Console.WriteLine($"Inneholder treet 40? {numbers.Contains(40)}");
// Console.WriteLine($"Inneholder treet 55? {numbers.Contains(55)}");



// ...

Console.WriteLine(GetMiddle);