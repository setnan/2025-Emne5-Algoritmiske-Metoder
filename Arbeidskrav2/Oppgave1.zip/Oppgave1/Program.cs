﻿﻿namespace Oppgave1;
using Oppgave1;

using BenchmarkDotNet.Running;



// testing
// Console.WriteLine($"Fibonacci of 0 is: {Recursion.Fibonacci(0)}");
// Console.WriteLine($"Fibonacci of 6 is: {Recursion.Fibonacci(6)}");
// Console.WriteLine($"Fibonacci of 10 is: {Recursion.Fibonacci(10)}");

// Console.WriteLine("--- --- --- --- ---");

// Console.WriteLine($"Iterative Fibonacci of 0 is: {Iteration.Fibonacci(0)}");
// Console.WriteLine($"Iterative Fibonacci of 6 is: {Iteration.Fibonacci(6)}");
// Console.WriteLine($"Iterative Fibonacci of 10 is: {Iteration.Fibonacci(10)}");

// Benchmark recursion vs iteration
// Replace 'SumBenchmark' with the correct benchmark class name, or define it if missing.
// Example: If you want to benchmark Fibonacci methods, create a FibonacciBenchmark class and use it here.
// BenchmarkRunner.Run<FibonacciBenchmark>();

// If you have not defined any benchmark class, you can define one like this:
BenchmarkRunner.Run<FibonacciRecBenchmark>();

// FibonacciRec
BenchmarkRunner.Run<FibonacciIter>();