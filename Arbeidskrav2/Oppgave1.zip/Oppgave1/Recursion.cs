namespace Oppgave1;

public class Recursion
{

    public int FibonacciRec(int n)
    {
        if (n < 0 || n > 92)
        {
            throw new ArgumentOutOfRangeException(nameof(n), "n must be between 0 and 92 inclusive.");
        }
        if (n == 0) return 0;
        if (n == 1) return 1;
        return FibonacciRec(n - 1) + FibonacciRec(n - 2);
    }
}